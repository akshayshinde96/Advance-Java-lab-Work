import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginService {

	public boolean checkLogin(String username, String password) {
		String dbUsername;
		String dbPassword;
		boolean login=false;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pleasework", "root", "cdac");
			PreparedStatement st = conn.prepareStatement("select username,password from customer");
			ResultSet rs = st.executeQuery();
			
			while(rs.next()) {
				dbUsername = rs.getString("username");
				dbPassword = rs.getString("password");
				
				if(dbUsername.equals(username) && dbPassword.equals(password)) {
					System.out.println(dbUsername);
					System.out.println(dbPassword);
					login = true;
				}
			}
			
		}
		catch(Exception e) {
			
		}
		return login;
	}
}
