import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RegistrationServiceServlet {

	public boolean registerLogic(String username, String password, String email,int monumber) {
		String dbusername;
		String dbpassword;
		String dbemail;
		int dbmonumber;
boolean result = true;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/advancejava", "root", "cdac");
			PreparedStatement st = conn.prepareStatement("select * from customer");
			ResultSet rs = st.executeQuery();
			
			while(rs.next()) {
				dbusername= rs.getString("username");
			//	dbpassword = rs.getString("password");
				dbemail = rs.getString("email");
				dbmonumber = rs.getInt("mobileno");
				
				if(dbusername.equals(username) && dbemail.equals(email) && dbmonumber == (monumber)) {
					result = false;
				}
			}
		}
		catch(Exception e) {}
		return result;
	}

}
