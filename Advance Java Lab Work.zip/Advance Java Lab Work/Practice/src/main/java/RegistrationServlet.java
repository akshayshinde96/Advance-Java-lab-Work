

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	PrintWriter out = response.getWriter();
		
	String username = request.getParameter("username");
	String password = request.getParameter("password");
	int monumber = Integer.parseInt(request.getParameter("monumber"));
	String confirm = request.getParameter("confirm");
	String email = request.getParameter("email");
	
		if(!password.equals(confirm)) {
			out.write("<html><body>");
			out.write("<h1>Check password</h1>");
			out.write("</body></html>");
		}
		else {
			RegistrationServiceServlet rss = new RegistrationServiceServlet();
			boolean register = rss.registerLogic(username,password,email,monumber);
			
			if(!register) {
				
				try {

					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/advancejava", "root", "cdac");
					PreparedStatement st = conn.prepareStatement("insert into customer(username, password, mobileno, email) values(?, ?, ?, ?)");
					st.setString(1, username); //substituting ? with actual value
					st.setString(2,  password);
					st.setInt(3, monumber);
					st.setString(4,email);
					st.executeUpdate();
					conn.close();
				}catch(Exception e) {
					
				}
			}
		}
	}

}
