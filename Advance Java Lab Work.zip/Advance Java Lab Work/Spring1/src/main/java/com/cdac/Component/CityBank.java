package com.cdac.Component;

import org.springframework.stereotype.Component;

@Component("cityBank")
public class CityBank implements Bank{

	public boolean isAccountPresent(int accno) {
		if(accno==101010)
			return true;
		return false;
	}

	public void withdraw(int atmId, int acno, double amount) {
		System.out.println("Customer of CitiBank wants to withdraw money..");
	}
}
