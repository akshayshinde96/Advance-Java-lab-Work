package com.cdac.App;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.Component.HdfcBankAtm;

public class App {

	public static void main(String args[]) {
		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("my-spring-config.xml");
		
		HdfcBankAtm hdfcBankAtm = (HdfcBankAtm) ctx.getBean("hdfcAtm");
		hdfcBankAtm.withdraw(101010,5000.0 );
	}
}
