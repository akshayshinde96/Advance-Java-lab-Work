package com.cdac.Component;

import java.security.PublicKey;
import java.util.List;
import java.util.PrimitiveIterator.OfDouble;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("hdfcAtm")
public class HdfcBankAtm implements Atm{

	@Autowired
	private List<Bank> banks;
	
	public void withdraw(int accno, double amount) {
		
		System.out.println("HDFC customer wants to withdraw money");
		
		Bank currentBank = null;
		
		for (Bank bank : banks) {
			if(bank.isAccountPresent(accno)) {
				currentBank = bank;
				break;
			}
		}
		currentBank.withdraw(12345, accno, amount);
	}
}
