package com.cdac.Component;

public interface Atm {

	public void withdraw(int accno, double amount);
}
