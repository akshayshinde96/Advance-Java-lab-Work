package com.cdac.Component;

public interface Bank {
	
	public boolean isAccountPresent(int accno);
	public void withdraw(int atmId, int accno, double amount );
}
