package com.cdac.Component;

import org.springframework.stereotype.Component;

@Component("yesBank")
public class YesBank implements Bank{

	public boolean isAccountPresent(int accno) {
		if(accno==202020)
			return true;
		return false;
	}
	public void withdraw(int atmId,int accno,double amount) {
		System.out.println("Customer of Yes bank wants withdraw money...");
	}
}
