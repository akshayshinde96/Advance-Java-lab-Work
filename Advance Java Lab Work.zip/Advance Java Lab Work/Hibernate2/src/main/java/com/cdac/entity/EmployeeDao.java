package com.cdac.entity;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;




public class EmployeeDao {

	//data access object
	public void add(Employee emp) {
		
		//During this code persistence.xml file will be read
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		em.persist(emp);
		tx.commit();
		emf.close();
	}
	
	public Employee fetch(int empno) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em  = emf.createEntityManager();
		//EntityTransaction tx = em.getTransaction(); 
		
		Employee emp = em.find(Employee.class, empno);
		return emp;
	}

	public List<Employee> fetchAll() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();

		Query q = em.createQuery("select e from Employee e"); //HQL/JPQL
		List<Employee> list = q.getResultList();
		
		emf.close();
		return list;
	}
	
	public List<Employee>  fetchAllBySalary(float salary) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		
		Query q = em.createQuery("select e from Employee e where e.salary=  :sal");
		q.setParameter("sal",salary);
		
		List<Employee> list = q.getResultList();
		
		return list;
	}

	public List<Employee> fetchAllByName(String name) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		
		Query q = em.createQuery("select e from Emplyee e where empname = :ename");
		q.setParameter("ename",name);
		return null;
	}
}
