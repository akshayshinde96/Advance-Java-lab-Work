package com.cdac.component;

public interface PhoneBook {

	void add(PhoneBook1 phoneBook1);
	void remove(String name);
	void sort(String order);
	void search(String name);
}
