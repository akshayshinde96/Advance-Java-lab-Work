package com.cdac.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Component;


@Component("phoneBook")
public class PhoneBookImplement implements  PhoneBook{

	public void add(PhoneBook1 pbook) {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/advancejava", "shinde", "cdac");
			
			PreparedStatement st = conn.prepareStatement("insert into tbl_phoneBook(name,mobNo) values(?,?)");
			st.setString(1,pbook.getName());
			st.setLong(2, pbook.getMobNo());
			st.executeUpdate();
		}catch (Exception e) {
			e.getStackTrace();
		}finally {
			try{conn.close();}catch (Exception e) {
				// TODO: handle exception
			}
		}
		
	}

	public void remove(String name) {
		
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/advancejava", "shinde", "cdac");
			
			PreparedStatement st = conn.prepareStatement("delete from  tbl_phoneBook where name= ?");
			st.setString(1,name);
			
			st.executeUpdate();
		}catch (Exception e) {
			e.getStackTrace();
		}finally {
			try{conn.close();}catch (Exception e) {
				// TODO: handle exception
			}
		}
		
	}

	public void sort(String order) {
		// TODO Auto-generated method stub
		
	}

	public void search(String name) {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/advancejava", "shinde", "cdac");
			
			PreparedStatement st = conn.prepareStatement("select name,mobNo from  tbl_phoneBook where name= ?");
			st.setString(1,name);
			ResultSet rs =  st.executeQuery();
			
			while(rs.next()) {
				System.out.println(((PhoneBook1) rs).getName()+" "+((PhoneBook1) rs).getMobNo());
			}
		}catch (Exception e) {
			e.getStackTrace();
		}finally {
			try{conn.close();}catch (Exception e) {
				// TODO: handle exception
			}
		}
		
	}

}
