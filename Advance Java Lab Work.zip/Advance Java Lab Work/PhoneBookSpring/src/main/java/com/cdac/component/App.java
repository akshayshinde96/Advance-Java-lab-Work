package com.cdac.component;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String args[]) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("my-spring-config.xml");
		
		PhoneBook pk = (PhoneBook) ctx.getBean("phoneBook");
		
	/*	PhoneBook1 ph = new PhoneBook1();
		ph.setName("Akash Barhate");
		ph.setMobNo(656652);
		
		pk.add(ph);*/
		
		pk.remove("Akash Shinde");
		
		pk.search("Akash Barhate");
	}
}
