package AlbumSong;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.criterion.AggregateProjection;

public class GenericDao {

	public void save(Object obj) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		try{
			EntityManager em = emf.createEntityManager();
			EntityTransaction tx = em.getTransaction();
			tx.begin();
	
			em.persist(obj); //persist method will generate insert query
			
			tx.commit();
		}
		finally {
			emf.close();
		}
	}
	
	public Object fetchById(Class clazz, Object pk) {
		EntityManagerFactory emf =  Persistence.createEntityManagerFactory("learning-hibernate");
		try {
			EntityManager em = emf.createEntityManager();
			EntityTransaction tx = em.getTransaction();
			
	
			Object object =  em.find(clazz,pk); 
			return object;
		}finally {
			emf.close();
		}
		
	}
	
	public void removeById(Class clazz,Object pk) {
		EntityManagerFactory emf =  Persistence.createEntityManagerFactory("learning-hibernate");
		try {
			EntityManager em = emf.createEntityManager();
			EntityTransaction tx = em.getTransaction();
			tx.begin();
			
			Object object = em.find(clazz, pk);
			em.remove(object);
			
			tx.commit();
		}finally {
			emf.close();
		}
	}
}
