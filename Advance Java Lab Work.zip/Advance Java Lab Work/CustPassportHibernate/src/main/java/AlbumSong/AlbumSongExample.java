package AlbumSong;

import java.time.LocalDate;
import java.util.Set;

public class AlbumSongExample {

	public static void main(String args[]) {
		GenericDao dao = new GenericDao();
		
	/*	Album album = new Album();
		album.setName("Best Of 2021");
		album.setReleaseDate(LocalDate.of(2021, 10, 4));
		album.setCopyRight("T-series Music Co.");
		dao.save(album);
		
		Song song = new Song();
		song.setTitle("Shape of you");
		song.setArtist("ed shareen");
		
		song.setAlbum(album);
		dao.save(song);*/
		
		Album album = (Album) dao.fetchById(Album.class,2);
		System.out.print(album.getCopyRight()+" "+album.getName()+" "+album.getReleaseDate());
	
		dao.removeById(Song.class, 2);
	}
}
