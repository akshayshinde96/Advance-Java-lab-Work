package ManyToMany;

import java.util.ArrayList;
import java.util.List;

import AlbumSong.GenericDao;

public class AuthorBookExample {

	public static void main(String args[]) {
		
		GenericDao dao = new GenericDao();
		
		Author author = new Author();
		author.setName("J K Rowlings");
		author.setEmail("jowlings@gmail");
	//	dao.save(author);
		
		Book book1 = new Book();
		book1.setName("Harry potter and chamber the secret");
		book1.setCost(895);
		//dao.save(book1);
		
		Book book2 = new Book();
		book2.setName("Harry potter and deadly hollows");
		book2.setCost(895);
		
		List<Book> list = new ArrayList<Book>();
		list.add(book1);
		list.add(book2);
		
		author.setBooks(list);
		dao.save(author);
	}
}
