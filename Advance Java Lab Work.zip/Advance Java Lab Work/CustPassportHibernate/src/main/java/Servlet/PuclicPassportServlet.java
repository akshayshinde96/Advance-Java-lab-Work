package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import PersonPassport.Passport;
import PersonPassport.Person;
import PersonPassport.PersonPassportDao;

/**
 * Servlet implementation class PuclicPassportServlet
 */
public class PuclicPassportServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	/*	Person person = new Person();
		person.setName("Akshay");
		person.setDateOfBirthDate(LocalDate.of(2022, 10, 22));
		person.setEmail("akshay@gmail");
		
		Passport passport = new Passport();
		passport.setIssueDate(LocalDate.of(2021,10 , 22));
		passport.setExpiryDate(LocalDate.of(2030, 12, 22));
		passport.setIssueByString("Govt Of India");
		
		person.setPassport(passport);
		passport.setPerson(person);
		
		dao.add(person);*/
		 /*
		  * PrintWriter out = response.getWriter();
		Employee1 empo =new Employee1();
		empo.setEmpno(Integer.parseInt(request.getParameter("Empno")));
		empo.setName(request.getParameter("Empname"));
		empo.setSalary(Double.parseDouble(request.getParameter("salary")));
		empo.setDateOfJoin(LocalDate.parse(request.getParameter("date_of_join")));
		
		EmployeeDao emd =new EmployeeDao();
		emd.add(empo);
		
		out.write("<h1>Record Added!<h1>");
		 */
		PersonPassportDao dao = new PersonPassportDao();
		
		Person person = new Person();
		person.setName(request.getParameter("name"));
		person.setDateOfBirthDate(LocalDate.parse(request.getParameter("dob")));
		person.setEmail(request.getParameter("email"));
		
		Passport passport = new Passport();
		passport.setIssueDate(LocalDate.parse(request.getParameter("issuedate")));
		passport.setExpiryDate(LocalDate.parse(request.getParameter("exdate")));
		passport.setIssueByString(request.getParameter("issuedby"));
		
		person.setPassport(passport);
		passport.setPerson(person);
		
		dao.add(person);
	}

}
