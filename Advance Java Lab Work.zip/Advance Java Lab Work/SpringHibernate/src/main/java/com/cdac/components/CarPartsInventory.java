package com.cdac.components;

import java.util.List;

public interface CarPartsInventory {

	public void addNewParts(CarParts carParts);
	public List<CarParts> getAvailableParts();
}
