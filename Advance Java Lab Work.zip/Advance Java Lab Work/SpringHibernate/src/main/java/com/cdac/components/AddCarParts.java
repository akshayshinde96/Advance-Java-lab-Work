package com.cdac.components;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;
@Component("carparts")
public class AddCarParts implements CarPartsInventory{

	public void addNewParts(CarParts carParts) {
		

		//@Autowired doesn't works if we need to inject EntityManager object
		@PersistenceContext
		private EntityManager em;
		
		@Override
		@Transactional
		public void addNewPart(CarPart carPart) {
			em.persist(carPart);
		}
	}

	public List<CarParts> getAvailableParts() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
