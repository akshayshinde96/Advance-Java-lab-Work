package com.cdac.component;

import org.springframework.beans.factory.annotation.Autowired;

public class Car {
	@Autowired
	private Engine en;
	public void carModel(String car) {
		if(car.equals("I10")) {
			en.engineCC("I10");
		}else {
			en.engineCC("Honda");
		}
	}
}
