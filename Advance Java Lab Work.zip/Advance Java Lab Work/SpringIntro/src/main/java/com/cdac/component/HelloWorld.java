package com.cdac.component;

public class HelloWorld {

	public void hello(String name) {
		System.out.println("Hello"+" "+name);
	}
}
