package com.cdac.component;

public class Engine {

	public void engineCC(String car) {
		if(car.equals("I10")) {
			System.out.println("car has a 2200 CC engine");
		}else {
			System.out.println("car has a 1800 CC engine");
		}
	}
}
