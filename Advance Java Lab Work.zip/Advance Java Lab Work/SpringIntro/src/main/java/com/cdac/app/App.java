package com.cdac.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cdac.component.Car;
import com.cdac.component.HelloWorld;
import com.cdac.component.MathOperation;
import com.cdac.component.TextEditor;

public class App {

	public static void main(String arfgs[]) {
		//Loading Spring/IOC Container
				ApplicationContext ctx = new ClassPathXmlApplicationContext("my-spring-config.xml");
				//Accessing a particular bean
				HelloWorld hw = (HelloWorld) ctx.getBean("hello");
			hw.hello("Akshay");
			
			MathOperation op = (MathOperation) ctx.getBean("math");
			op.math(50, 60);
			
			TextEditor text  = (TextEditor) ctx.getBean("textEditor");
			text.load("text.txt");
			
			Car c = (Car) ctx.getBean("car");
			c.carModel("I10");
			c.carModel("Honda");
	}
}
