package com.cdac.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("textEditor")
public class TextEditor {

	@Autowired
	private SpellingCheck check;
	public void load(String document) {
		
		check.spellCheck(document);
	}
}
