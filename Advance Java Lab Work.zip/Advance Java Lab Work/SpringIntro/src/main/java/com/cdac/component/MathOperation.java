package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("math")
public class MathOperation {

	public void math(int x, int y) {
		
		System.out.println("addition : "+(x + y));
		System.out.println("substraction : "+(x - y));
	}
}
