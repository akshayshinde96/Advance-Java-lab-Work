package com.cdac.component;

import org.springframework.stereotype.Component;

@Component("spellChecker")
public class SpellingCheck {

	public void spellCheck(String text) {
		System.out.println("some code for spelling check "+text);
	}
}
