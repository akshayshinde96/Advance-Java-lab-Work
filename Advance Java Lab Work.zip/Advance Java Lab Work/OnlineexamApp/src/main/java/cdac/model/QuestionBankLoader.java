package cdac.model;

import java.util.ArrayList;
import java.util.List;

public class QuestionBankLoader {

	public List<Question> loadQuestionsOnJava(){
		//method with return type List<Question>
		
		QuestionBank qb = new QuestionBank();
		
		qb.addNewSubject("java");
		Question q = new Question("Question 1");//Question.java add question using constructor
		List<Option> ops = new ArrayList<Option>();
		ops.add(new Option("Option 1",false));
		ops.add(new Option("Option 2",false));
		ops.add(new Option("Option 3",false));
		ops.add(new Option("Option 4",true));
		
		q.setOptions(ops);//option set for question //Method in Option.java
		
		qb.addNewQuestion("java", q); //QuestionBank.java  add new question
		
	//2nd question	
		q = new Question("Question 2");//Question.java add question using constructor
		ops = new ArrayList<Option>();
		ops.add(new Option("Option 1",false));
		ops.add(new Option("Option 2",false));
		ops.add(new Option("Option 3",false));
		ops.add(new Option("Option 4",true));
		
		q.setOptions(ops);//option set for question //Method in Option.java
		
		qb.addNewQuestion("java", q); //QuestionBank.java  add new question
		return qb.fetchQuestionsOn("java");
		
	}
}
