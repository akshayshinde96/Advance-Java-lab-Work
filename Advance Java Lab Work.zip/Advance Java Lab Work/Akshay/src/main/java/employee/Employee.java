package employee;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/EmployeeDetails")
public class Employee extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		int empno = Integer.parseInt(request.getParameter("empno"));
		
	//	SearchDetails search = new SearchDetails();
		//int isFind = search.SearchDetailslogic(empno);

		String DBempno;
		String DBename;
		String DBemail;
		String DBsal;
		
	//	boolean Find = false;
		if("empno"!=null) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pleasework", "root", "cdac");
			
				PreparedStatement ps = conn.prepareStatement("select * from employeee");
				ResultSet rs = ps.executeQuery();
			//	ps.setString()
				while(rs.next()) {
					DBempno = rs.getString("empno");
					if(DBempno.equals(empno)) {
						DBename = rs.getString("ename");
						DBemail = rs.getString("DBemail");
						DBsal = rs.getString("DBsal");
					}
				}
			}catch(Exception e) {
				
			}
			out.write("empno"+"ename"+"email"+"sal");
		}
	}

}
