package employee;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SearchDetails {

	public int SearchDetailslogic(int empno) {
		
		String DBempno;
		String DBename;
		String DBemail;
		String DBsal;
		
		boolean Find = false;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pleasework", "root", "cdac");
		
			PreparedStatement ps = conn.prepareStatement("select * from employeee");
			ResultSet rs = ps.executeQuery();
		//	ps.setString()
			while(rs.next()) {
				DBempno = rs.getString("empno");
				if(DBempno.equals(empno)) {
					DBename = rs.getString("ename");
					DBemail = rs.getString("DBemail");
					DBsal = rs.getString("DBsal");
				}
			}
		}catch(Exception e) {
			
		}
		return 0;
	}

}
