package com.addSub.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AssignmentNo2.AddSum")
public class AssignmentNo2 extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		int number1 = Integer.parseInt(request.getParameter("number1"));
		int number2 = Integer.parseInt(request.getParameter("number2"));

		
		
		PrintWriter out = response.getWriter();
		/*String requestType = request.getParameter("add");
		if(requestType.equals("add")) {
			int sum = number1 + number2;
			System.out.println("sum : "+sum);
		}  else if(requestType.equals("sub")){
			int sub = number1 - number2;
			System.out.println("sub : "+sub);
		}
*/
		if(request.getParameter("add")!=null) {
			int sum = number1 + number2;
			//System.out.println("sum : "+sum);
			
			out.write("<html><body>");
			out.write("<h1>"+sum+"</h1>");
			out.write("</body></html>");
		}
		
		if(request.getParameter("sub")!=null) {
			int sub = number1 - number2;
			//System.out.println("sum : "+sum);
			
			out.write("<html><body>");
			out.write("<h1>"+sub+"</h1>");
			out.write("</body></html>");
		}
	
		/*String requestType1 = request.getParameter("delete");
		if(requestType1.equals("delete")){
			int sub = number1 - number2;
			System.out.println("sub : "+sub);
		}*/
	
		
	
	}

}
