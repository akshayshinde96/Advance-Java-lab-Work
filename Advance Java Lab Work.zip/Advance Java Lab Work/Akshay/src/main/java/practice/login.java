package practice;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/practice/login")
public class login extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String captcha = request.getParameter("captcha");
		
		LoginService loginservice = new LoginService();
		boolean isValid = loginservice.check(password,username);
		
		if(isValid) {
			
			CaptchaServlet cs = new CaptchaServlet();
			boolean captchaCheck =cs.captchaCheck("captcha");
			if(captchaCheck) {
				response.sendRedirect("welcome.html");
			}
			else
				response.sendRedirect("login.html");
		}
		else {
			response.sendRedirect("login.html");
		}
	}

}
