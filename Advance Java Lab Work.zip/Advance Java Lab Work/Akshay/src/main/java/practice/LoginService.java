package practice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.mysql.cj.xdevapi.Statement;

public class LoginService {
	// String query;
     String dbUsername, dbPassword;
     boolean login = false;
	public boolean check(String password, String username) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pleasework", "root", "cdac");
			//Statement stmt = (Statement) conn.createStatement();
			//query = "select username, password from customer;";
			PreparedStatement st = (PreparedStatement)conn.prepareStatement("select username,password from customer");
			ResultSet rs = (ResultSet)st.executeQuery();

			while(rs.next()) {
				dbUsername = rs.getString("username");
                dbPassword = rs.getString("password");
                
                if(dbUsername.equals(username) && dbPassword.equals(password)) {
                	login = true;
                }
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		return login;
	}

}
