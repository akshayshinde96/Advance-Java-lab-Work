package day2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LogicRegisterService {

	public boolean checkEmail(String email) {


		 String dbEmail;
	     boolean registration = true;
		
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pleasework", "root", "cdac");
			
				PreparedStatement st = (PreparedStatement)conn.prepareStatement("select email from customer");
				ResultSet rs = (ResultSet)st.executeQuery();

				while(rs.next()) {
					dbEmail = rs.getString("email");
	           
	                
	                if(dbEmail.equals(email) ) {
	                	registration = false;
	                }
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
			
		return registration;
	}

}
