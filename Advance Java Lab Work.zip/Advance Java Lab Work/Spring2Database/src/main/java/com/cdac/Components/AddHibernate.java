package com.cdac.Components;

import java.util.List;



import org.springframework.stereotype.Component;
@Component("carParts")
public class AddHibernate implements CarPartsInventory{

	
	public void addNewParts(CarParts carParts) {
		//@Autowired doesn't works if we need to inject EntityManager object
		@PersistenceContext
		private EntityManager em;
		
		@Override
		@Transactional
		public void addNewPart(CarPart carPart) {
			em.persist(carPart);
		}
		
	}

	public List<CarParts> getAvailableParts() {
		// TODO Auto-generated method stub
		return null;
	}

}
