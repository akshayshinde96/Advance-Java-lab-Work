package com.cdac.Components;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import org.springframework.stereotype.Component;
@Component("carParts")
public class CarpartsInventoryImplements implements CarPartsInventory{
	
	public void addNewParts(CarParts carParts) {
		Connection conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/advancejava", "shinde", "cdac");
		
			PreparedStatement st = conn.prepareStatement("insert into tbl_carpart(part_name, car_model, price, quantity) values(?, ?, ?, ?)");
			st.setString(1, carParts.getPartName());
			st.setString(2, carParts.getCarModel());
			st.setDouble(3, carParts.getPrice());
			st.setInt(4, carParts.getQuanity());
			st.executeUpdate();
			
		}catch (Exception e) {
			e.getStackTrace();
		}finally {
			try { conn.close(); } catch(Exception e) { }
		}	
		
	}

	public List<CarParts> getAvailableParts() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
