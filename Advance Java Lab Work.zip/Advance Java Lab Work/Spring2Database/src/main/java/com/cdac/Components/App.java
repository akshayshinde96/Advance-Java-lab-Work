package com.cdac.Components;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String args[]) {
		
ApplicationContext ctx = new ClassPathXmlApplicationContext("my-spring-config.xml");
		
		CarPartsInventory inv = (CarPartsInventory) ctx.getBean("carParts2");
		
		CarParts carParts = new CarParts();
		
		carParts.setPartName("silencer");
		carParts.setCarModel("I10");
		carParts.setPrice(35000);
		carParts.setQuanity(10);
		
		inv.addNewParts(carParts);
	}
}
