package com.cdac.Components2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Component;
@Component("addmission")
public class AddmissionImplementation implements Addimission{

	public void addNewStudent(Student student) {
		Connection conn = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/advancejava", "shinde", "cdac");

			PreparedStatement stmt = conn.prepareStatement("insert into tbl_student(name,age,gender) values(?,?,?)");
			stmt.setString(1,student.getName());
			stmt.setInt(2, student.getAge());
			stmt.setString(3, student.getGender());
			stmt.executeUpdate();
			
			
		}catch (Exception e) {
			try {
				conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		
	}

	public List<Student> getStudentData(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
