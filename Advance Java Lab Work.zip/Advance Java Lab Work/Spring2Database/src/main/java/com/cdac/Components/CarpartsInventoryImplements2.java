package com.cdac.Components;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component("carParts2")
public class CarpartsInventoryImplements2 implements CarPartsInventory{
	
	@Autowired
	private DataSource dataSource;
	
	public void addNewParts(CarParts carParts) {
		Connection conn = null;
		try {
			long ms1 = System.currentTimeMillis();
			conn = dataSource.getConnection();
			long ms2 = System.currentTimeMillis();
			System.out.println("Approx time taken to obtain a connection from the pool : " + (ms2 - ms1) + " ms");
			
			PreparedStatement st = conn.prepareStatement("insert into tbl_carpart(part_name, car_model, price, quantity) values(?, ?, ?, ?)");
			st.setString(1, carParts.getPartName());
			st.setString(2, carParts.getCarModel());
			st.setDouble(3, carParts.getPrice());
			st.setInt(4, carParts.getQuanity());
			st.executeUpdate();
			
		}catch (Exception e) {
			e.getStackTrace();
		}finally {
			try { conn.close(); } catch(Exception e) { }
		}	
		
	}

	public List<CarParts> getAvailableParts() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
