package com.cdac.Components2;

import java.util.List;

public interface Addimission {

	public void addNewStudent(Student student);
	public List<Student> getStudentData(String name);
}
