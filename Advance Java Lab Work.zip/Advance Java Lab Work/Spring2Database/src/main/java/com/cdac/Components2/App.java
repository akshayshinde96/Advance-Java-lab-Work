package com.cdac.Components2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String args[]) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("my-spring-config.xml");

		Addimission adm =(Addimission) ctx.getBean("addmission");
		
		Student student = new Student();
		student.setName("Akash");
		student.setAge(26);
		student.setGender("male");
		adm.addNewStudent(student);
	}
}
