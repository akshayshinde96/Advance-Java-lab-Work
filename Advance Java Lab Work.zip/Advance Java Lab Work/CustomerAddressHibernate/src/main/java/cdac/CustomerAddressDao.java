package cdac;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class CustomerAddressDao {

	//******************* add ************************
	public void add(Customer cust) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();

		em.persist(cust); //persist method will generate insert query
		
		tx.commit();
		emf.close();
	}
	
	public void add(Address addr) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		
		em.persist(addr);
		
		tx.commit();
		emf.close();
	}
	
	//****************** fetchById***********************
	
	public Customer fetchById(int id) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		
		Customer cust = em.find(Customer.class,id);
		emf.close();

		return cust;	
	}
	//****************** fetchByCity***********************

	public List<Customer> fetchByCity(String city) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();

		Query q = em.createQuery("select c from Customer c join c.address a where a.city = :ct");
		q.setParameter("ct", city);
		List<Customer> list = q.getResultList();
		
		emf.close();

		return list;
	}
	
	//***************fetchByState****************************
	
	public List<Customer> fetchByState(String state){
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		Query q = em.createQuery("select c from Customer c join c.address a where a.state = :st");
		q.setParameter("st", state);
		
		List<Customer> list = q.getResultList();
		
		emf.close();
		
		return list;
	}
}
