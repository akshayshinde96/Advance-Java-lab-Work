package cdac;

import java.util.List;

public class AddCustomerAddress {

	public static void main(String args[]) {
		CustomerAddressDao dao = new CustomerAddressDao();
	/*	
		Customer c = new Customer();
		c.setName("Shubham");
		c.setEmail("shubhamshinde@outlook.com");
	//	dao.add(c);
		
		Address a = new Address();
		a.setCity("Shrirampur");
		a.setPin(411709);
		a.setState("Maharastra");
	//	dao.add(a);
		
		c.setAddress(a);
		dao.add(c);
		
	*/
		/*
		Customer c = dao.fetchById(1);
		
		
		System.out.println("name"+c.getName()+" email"+c.getEmail());
	*/
	
		//List<Customer> list = dao.fetchCustomersByEmail("outlook");
				List<Customer> list = dao.fetchByCity("Shrirampur");
				for(Customer c : list)
					System.out.println(c.getId() + " " + c.getName() + " " + c.getEmail());
	
		
		List<Customer> list2 = dao.fetchByState("Maharastra");
		for (Customer customer : list2) {
			System.out.println(customer.getId() + " " + customer.getName() + " " + customer.getEmail());
		}
	}
}












//*************************************************
/*Customer c = new Customer();
		c.setId(60);
		c.setName("Mohini");
		c.setEmail("Mohini@gmail.com");
		
		
		Address a = new Address();
		a.setId(600);
		a.setPincode(606060);
		a.setCity("viman nagar");
		a.setState("MH");
		
		
		c.setAddress(a); // we have create obj of address class in customer to establish relationship(fk) 
		dao.add(c);

*/