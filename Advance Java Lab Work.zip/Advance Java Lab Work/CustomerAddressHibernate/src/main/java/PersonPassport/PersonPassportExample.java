package PersonPassport;

import java.time.LocalDate;
import java.util.List;

public class PersonPassportExample {

	public static void main(String args[]) {
		PersonPassportDao dao = new PersonPassportDao();
		
	/*	Person person = new Person();
		person.setName("Akshay");
		person.setDateOfBirthDate(LocalDate.of(2022, 10, 22));
		person.setEmail("akshay@gmail");
		
		Passport passport = new Passport();
		passport.setIssueDate(LocalDate.of(2021,10 , 22));
		passport.setExpiryDate(LocalDate.of(2030, 12, 22));
		passport.setIssueByString("Govt Of India");
		
		person.setPassport(passport);
		passport.setPerson(person);
		
		dao.add(person);*/
		
		List<Person> list = dao.fetchByName("Akshay");
		
		for (Person person : list) {
			System.out.println(person.getName()+" "+person.getEmail()+" "+person.getPassport().getPassportNo());
		}
		
	}
}
