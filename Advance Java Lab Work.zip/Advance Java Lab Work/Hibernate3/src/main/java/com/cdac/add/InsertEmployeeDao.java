package com.cdac.add;

import java.time.LocalDate;

import com.cdac.entity.Employee;
import com.cdac.entity.EmployeeDao;

public class InsertEmployeeDao {

	public static void main(String args[]) {
	/*	Employee emp = new Employee();
		emp.setEmpno(1003);
		emp.setEmpname("Akash");
		emp.setSalary(98000);
		emp.setDateOfJoining(LocalDate.of(2022, 10, 10));
		
		EmployeeDao dao = new EmployeeDao();
		dao.add(emp);
		*/
		
	}
}
