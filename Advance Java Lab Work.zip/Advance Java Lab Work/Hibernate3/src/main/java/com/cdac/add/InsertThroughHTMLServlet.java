package com.cdac.add;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cdac.entity.Employee;
import com.cdac.entity.EmployeeDao;

/**
 * Servlet implementation class InsertThroughHTMLServlet
 */
@WebServlet("/InsertThroughHTMLServlet")
public class InsertThroughHTMLServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Employee emp = new Employee();
		emp.setEmpno(Integer.parseInt(request.getParameter("empno")));
		emp.setEmpname(request.getParameter("name"));
		emp.setSalary(Float.parseFloat(request.getParameter("salary")));
		emp.setDateOfJoining(LocalDate.parse(request.getParameter("dateofjoining")));

		EmployeeDao dao = new EmployeeDao();		
		dao.add(emp);
		
	}

}
